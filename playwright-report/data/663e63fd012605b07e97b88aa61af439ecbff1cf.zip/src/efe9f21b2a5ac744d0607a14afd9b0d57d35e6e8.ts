import { expect, Page, type Locator } from '@playwright/test';
import type { SalesforceTestData } from '../utils/ExcelTestDataUtil';
import { PlaywrightUtil } from '../utils/PlaywrightUtil';

export class AccountCreationPage {
	private readonly playwright: PlaywrightUtil;

	constructor(private readonly page: Page) {
		this.playwright = new PlaywrightUtil(page);
	}

	private async openNewAccount(recordType: string): Promise<Locator> {		

		const recordTypeOption = this.page.getByRole('radio', { name: recordType, exact: true });
		if (await recordTypeOption.isVisible().catch(() => false)) {
			await this.playwright.click(recordTypeOption.locator('..').locator('label'));
			await this.playwright.click(this.page.getByRole('button', { name: /next|continue/i }));
		}

		const accountDialog = this.page.getByRole('dialog', {
			name: `New Account Management: ${recordType}`,
			exact: true,
		});
		await this.playwright.waitForVisible(accountDialog);
		return accountDialog;
	}

	private async fillAccountAddress(data: SalesforceTestData): Promise<void> {
		//await this.page.waitForTimeout(60000);
		await this.chooseOption('Region', data.billingRegion);
		await this.chooseOption('Select Address (Country/Territory)', data.billingCountry);
		// await expect(
		// 	this.page.getByRole('combobox', { name: 'Select Address (Country/Territory)', exact: true }),
		// ).toHaveText(data.billingCountry);
		// await expect(
		// 	this.page.getByRole('combobox', { name: 'Select Address (State/Province)', exact: true }),
		// ).toHaveText(data.billingState);
		await this.playwright.fill(this.page.getByLabel('Select Address (Street)', { exact: true }), data.billingStreet);
		await this.playwright.fill(this.page.getByLabel('Select Address (City)', { exact: true }), data.billingCity);
		await this.chooseOption('Select Address (State/Province)', data.billingState);
		await this.playwright.fill(this.page.getByLabel('Select Address (ZIP/Postal Code)', { exact: true }), data.billingPostalCode);
	}

	private async selectRegion(value: string): Promise<void> {		
		const firstOption = this.page.locator(`//button[@aria-label='Region']`);
		await this.playwright.click(firstOption);
		await this.playwright.click(this.page.getByRole('option', { name: value, exact: true }));
	}

	private async chooseOption(label: string, value: string): Promise<void> {
		const combobox = this.page.getByRole('combobox', { name: label, exact: true });
		await this.playwright.selectFromDropdown(combobox, this.page.getByRole('option', { name: value, exact: true }), value);
	}

	private async approveAndSave(): Promise<void> {
		await this.chooseOption('Status', 'Approved');
		await this.playwright.click(this.page.getByRole('button', { name: 'Save', exact: true }));
	}

	private async publishAccount(): Promise<void> {
		const publishButton = this.page.getByRole('button', { name: 'Publish', exact: true });
		if (await publishButton.isVisible().catch(() => false)) {
			await this.playwright.click(publishButton);
			return;
		}
		await this.playwright.click(this.page.getByRole('button', { name: 'Show more actions', exact: true }));
		await this.playwright.click(this.page.getByRole('menuitem', { name: 'Publish', exact: true }));
	}

	async navigateToAccountCreation(): Promise<void> {
		await this.playwright.click(this.page.getByRole('link', { name: 'Accounts', exact: true }));
		await this.playwright.click(this.page.getByRole('button', { name: 'New', exact: true }));
		await this.playwright.click(this.page.getByText('Request for New Account', { exact: true }));
	}

	async createSalesAccountAndPublish(data: SalesforceTestData): Promise<string> {
		const accountDialog = await this.openNewAccount(data.salesRecordType);
		await this.playwright.fill(accountDialog.getByRole('textbox', { name: 'Account Name', exact: true }), data.salesAccountName);
		const website = `www.${data.salesAccountName.replace(/\s+/g, '').toLowerCase()}.com`;
		await this.playwright.fill(accountDialog.getByRole('textbox', { name: 'Website', exact: true }), website);
		await this.chooseOption('Lead Source', data.leadSource);
		await this.chooseOption('New Account Reason', data.newAccountReason);
		await this.chooseOption('Lead Source Detail', data.leadSourceDetail);
		//await this.page.getByLabel('Lead Source Detail', { exact: true }).fill(data.leadSourceDetail);
		await this.fillAccountAddress(data);
		await this.approveAndSave();
		await this.publishAccount();
		return data.salesAccountName;
	}

	async createLegalEntityAccountAndPublish(
		data: SalesforceTestData,
		salesAccountName: string,
	): Promise<string> {
		const accountDialog = await this.openNewAccount(data.legalEntityRecordType);
		await this.playwright.fill(accountDialog.getByRole('textbox', { name: 'Account Name', exact: true }), data.legalEntityName);
		const parentAccount = accountDialog.getByRole('combobox', { name: 'Parent Account', exact: true });
		await this.playwright.fill(parentAccount, salesAccountName);
		await this.playwright.click(accountDialog.getByRole('option', { name: salesAccountName, exact: true }));
		await this.chooseOption('Currency', data.opportunityCurrency);
		await this.fillAccountAddress(data);
		await this.approveAndSave();
		await this.publishAccount();
		return data.legalEntityName;
	}
}