import { test } from '@playwright/test';
import { runStep } from '../../../utils/StepReportUtil';
import { readTestData } from '../../../utils/ExcelTestDataUtil';
import { LoginPage } from '../../../pages/LoginPage';
import { AccountCreationPage } from '../../../pages/AccountCreationPage';
import { BaseUtils } from '../../../utils/BaseUtils';

test('DLROTC_1234 New Logo DFW010 Test', async ({ page }, testInfo) => {

	const testData = await readTestData(testInfo.title);
	const login = new LoginPage(page);
	const accountCreation = new AccountCreationPage(page);
	await runStep(page, testInfo, 'Navigate to Salesforce', async () => {
		await page.goto(testData.applicationUrl);
	});

	await runStep(page, testInfo, 'Login to Salesforce', async () => {
		await login.loginToSalesforce(testData.username, testData.password);
	});

	await runStep(page, testInfo, 'Navigate to Account Creation Page', async () => {
		await accountCreation.navigateToAccountCreation();
	});

	let salesAccountName = testData.salesAccountName+BaseUtils.getFormattedDateStamp("SA");
	await runStep(page, testInfo, 'Create and publish Sales Account', async () => {
		salesAccountName = await accountCreation.createSalesAccountAndPublish({
			...testData,
			salesAccountName,
		});
	});

	await runStep(page, testInfo, 'Create and publish Legal Entity', async () => {
		await accountCreation.createLegalEntityAccountAndPublish(testData, salesAccountName);
	});

});